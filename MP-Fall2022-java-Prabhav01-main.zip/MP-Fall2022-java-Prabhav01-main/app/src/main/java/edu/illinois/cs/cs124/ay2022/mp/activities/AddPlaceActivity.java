package edu.illinois.cs.cs124.ay2022.mp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import edu.illinois.cs.cs124.ay2022.mp.R;
import edu.illinois.cs.cs124.ay2022.mp.models.Place;
import edu.illinois.cs.cs124.ay2022.mp.models.ResultMightThrow;
import edu.illinois.cs.cs124.ay2022.mp.network.Client;
import java.util.function.Consumer;

public class AddPlaceActivity extends AppCompatActivity
    implements Consumer<ResultMightThrow<Boolean>> {
  // private static final String TAG = AddPlaceActivity.class.getSimpleName();
  @Override
  public void onCreate(@Nullable final Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    // Code for cancel
    setContentView(R.layout.activity_addplace);
    Intent returnToMain = new Intent(this, MainActivity.class);
    returnToMain.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
    Button cancelButton = findViewById(R.id.cancel_button);
    cancelButton.setOnClickListener(v -> startActivity(returnToMain));
    // review
    Button reviewButton = findViewById(R.id.save_button);
    cancelButton.setOnClickListener(v -> startActivity(returnToMain));
    // CODE for SAVE
    Intent save = getIntent();
    // gets location using intent
    String lat = save.getStringExtra("latitude");
    String lon = save.getStringExtra("longitude");
    Button saveButton = findViewById(R.id.save_button);
    saveButton.setOnClickListener(
        v -> {
          EditText editTxt = findViewById(R.id.description);
          EditText editRev = findViewById(R.id.review);
          // takes description as string
          String description = String.valueOf(editTxt.getText());
          String review = String.valueOf(editRev.getText());
          // call constructor, create place object
          Place place =
              new Place(
                  "51d45b22-b089-4ab5-9733-7d6f2a891d70",
                  "Student",
                  Double.parseDouble(lat),
                  Double.parseDouble(lon),
                  description,
                  review);
          Client.start().postFavoritePlace(place, this);
          startActivity(returnToMain);
        });
  }

  @Override
  public void accept(final ResultMightThrow<Boolean> booleanResultMightThrow) {}
}
