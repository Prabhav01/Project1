# CS 124 2022–2023 Machine Project (MP)

This is the Java starter code for the 2022–2023 CS 124 machine project (MP).
More information is available [here](https://cs124.org/MP/).
